﻿namespace NConsul.AspNetCore
{
    public class NConsulOptions
    {
        public string Address { get; set; }
        public string Token { get; set; }
    }
}